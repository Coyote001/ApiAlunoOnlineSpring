
package br.com.alunoonline.api.enums;

public enum FinanceiroStatusEnum {
    EM_DIA,
    EM_ATRASO,
    TRANCADO,
    CANCELADO;
}
