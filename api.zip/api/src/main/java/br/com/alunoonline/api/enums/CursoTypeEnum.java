
package br.com.alunoonline.api.enums;

public enum CursoTypeEnum {
    GRADUACAO,
    ESPECIALIZACAO,
    MESTRADO,
    DOUTORADO;
}
