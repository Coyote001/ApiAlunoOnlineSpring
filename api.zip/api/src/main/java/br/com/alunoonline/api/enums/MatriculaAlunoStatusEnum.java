
package br.com.alunoonline.api.enums;

public enum MatriculaAlunoStatusEnum {
    APROVADO,
    REPROVADO,
    TRANCADO,
    MATRICULADO;
}
